import{l as o,a as r}from"../chunks/BS1l8gpu.js";export{o as load_css,r as start};
