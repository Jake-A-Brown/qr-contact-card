import{l as o,a as r}from"../chunks/oHVZV-8J.js";export{o as load_css,r as start};
